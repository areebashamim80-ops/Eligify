from fastapi import APIRouter
from openai import OpenAI
from dotenv import load_dotenv
import os


# backend/.env ka exact path
BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.dirname(
            os.path.abspath(__file__)
        )
    )
)

ENV_PATH = os.path.join(BASE_DIR, ".env")

load_dotenv(ENV_PATH)


api_key = os.getenv("OPENAI_API_KEY")


router = APIRouter(
    prefix="/ai",
    tags=["Eligify AI"]
)


client = OpenAI(
    api_key=api_key
)


@router.post("/chat")
def chat(message: str):

    try:

        response = client.responses.create(
            model="gpt-5.6-luna",

            instructions="""
You are Eligify AI, an AI assistant for marginalized entrepreneurs.

Help entrepreneurs understand government schemes,
business opportunities, eligibility requirements,
documents and application guidance.

Be helpful, simple and clear.

Do not invent government schemes, eligibility rules,
benefits, documents, deadlines or application links.

When verified scheme data is not available,
clearly say that scheme-specific information needs
to be verified from official sources.
""",

            input=message
        )

        return {
            "reply": response.output_text,
            "status": "success"
        }


    except Exception as error:

        print("AI ERROR:", repr(error))

        return {
            "reply": f"AI ERROR: {str(error)}",
            "status": "error"
        }